/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;
import jcurl.core.dto.RockSetProps;
import junit.framework.TestCase;

/**
 * @see jcurl.core.RunComputer
 * @see jcurl.core.SlideSimpleTest
 * @see jcurl.core.CollissionSimpleTest
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RunComputerTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(RunComputerTest.class);
    }

    public void test010_hit() {
        final RockSet pos = RockSet.allHome();
        pos.getDark(0).setLocation(0, 5);
        pos.getLight(0).setLocation(0.2, 4.5);
        final RockSet speed = new RockSet();
        speed.getDark(0).setLocation(0, -1.0);

        // dynamics engines
        final Source src = new RunComputer(new SlideSimple(),
                new CollissionSimple(), new RockSetInterpolator(),
                RockSetProps.DEFAULT, 0, pos, speed);
        final RockSet rs = RockSet.allHome();
        src.getPos(100, rs);
        assertEquals("", 0, rs.getDark(0).getX(), 1e-6);
        assertEquals("", 4.899999961, rs.getDark(0).getY(), 1e-6);

        src.getPos(200, rs);
        assertEquals("", 0, rs.getDark(0).getX(), 1e-6);
        assertEquals("", 4.799999923, rs.getDark(0).getY(), 1e-6);

        src.getPos(300, rs);
        assertEquals("", -0.015340462, rs.getDark(0).getX(), 1e-9);
        assertEquals("", 4.717716693, rs.getDark(0).getY(), 1e-6);
        assertEquals("", 0.215340465, rs.getLight(0).getX(), 1e-9);
        assertEquals("", 4.482281684, rs.getLight(0).getY(), 1e-6);

        src.getSpeed(300, rs);
        assertEquals("", -0.494853615, rs.getDark(0).getX(), 1e-9);
        assertEquals("", -0.428446561, rs.getDark(0).getY(), 1e-6);
        assertEquals("", 0.494853615, rs.getLight(0).getX(), 1e-9);
        assertEquals("", -0.571553409, rs.getLight(0).getY(), 1e-6);

        src.getSpeed(1000, rs);
        assertEquals("", -0.494853615, rs.getDark(0).getX(), 1e-9);
        assertEquals("", -0.428446561, rs.getDark(0).getY(), 1e-6);
        assertEquals("", 0.494853615, rs.getLight(0).getX(), 1e-9);
        assertEquals("", -0.571553409, rs.getLight(0).getY(), 1e-6);
    }
}