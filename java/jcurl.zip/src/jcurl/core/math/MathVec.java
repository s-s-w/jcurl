/*
 * Created on 27.02.2005
 *
 */
package jcurl.core.math;

import java.awt.geom.Point2D;

/**
 * Helper class that brings some (2D-)vector artihmetics.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public final class MathVec {

    public static double abs(final Point2D a) {
        return Math.sqrt(scal(a, a));
    }

    public static Point2D add(final Point2D a, final Point2D b, final Point2D c) {
        final Point2D ret = c == null ? new Point2D.Float() : c;
        ret.setLocation(a.getX() + b.getX(), a.getY() + b.getY());
        return ret;
    }

    public static Point2D mult(final double fact, final Point2D a) {
        a.setLocation(a.getX() * fact, a.getY() * fact);
        return a;
    }

    public static double scal(final Point2D a, final Point2D b) {
        return a.getX() * b.getX() + a.getY() * b.getY();
    }

    public static Point2D sub(final Point2D a, final Point2D b, final Point2D c) {
        final Point2D ret = c == null ? new Point2D.Float() : c;
        ret.setLocation(a.getX() - b.getX(), a.getY() - b.getY());
        return ret;
    }

}