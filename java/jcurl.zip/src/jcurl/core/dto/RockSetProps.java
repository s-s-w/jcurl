/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

/**
 * Properties of a unique set of rocks (size, mass, etc.)
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockSetProps {

    public static final RockSetProps DEFAULT;
    static {
        DEFAULT = new RockSetProps();
        for (int i = DEFAULT.dark.length - 1; i >= 0; i--) {
            DEFAULT.dark[i] = RockProps.DEFAULT;
            DEFAULT.light[i] = RockProps.DEFAULT;
        }
    }

    private final RockProps[] dark = new RockProps[RockSet.ROCKS_PER_COLOR];

    private final RockProps[] light = new RockProps[RockSet.ROCKS_PER_COLOR];

    public RockSetProps() {
        for (int i = dark.length - 1; i >= 0; i--) {
            dark[i] = new RockProps();
            light[i] = new RockProps();
        }
    }

    public RockProps getDark(int i) {
        return dark[i];
    }

    public RockProps getLight(int i) {
        return light[i];
    }
}