/*
 * Created on 21.02.2005
 *
 */
package jcurl.core.dto;

/**
 * Base class for rock information (location or speed). The "Z" component is the
 * handle angle in radians.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public abstract class Rock extends Point3D implements Cloneable {
    public abstract Object clone();

    /**
     * Convenience method to check if zero or not.
     * 
     * @return
     */
    public abstract boolean nonzero();
}