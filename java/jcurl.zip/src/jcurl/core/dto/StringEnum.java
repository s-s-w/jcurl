/*
 * Created on 20.02.2005
 *  
 */
package jcurl.core.dto;

import java.util.Map;
import java.util.TreeMap;

class StringEnum extends EnumBase {

    private static int _idx = 0;

    private static final Map _names = new TreeMap();

    protected static final StringEnum find(String txt) {
        return (StringEnum) _names.get(txt);
    }

    private StringEnum(final String txt) {
        super(_idx++, txt);
        _names.put(txt, this);
    }
}