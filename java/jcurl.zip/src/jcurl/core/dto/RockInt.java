/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

import java.io.Serializable;

/**
 * Location or speed of a rock.
 * 
 * @see jcurl.core.dto.RockSet
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockInt extends Rock implements Serializable {

    static final float UNITS_PER_METER = 1.0e6F;

    static final float UNITS_PER_METER_PER_MILLI = 1.0e3F;

    final float scale;

    int x;

    int y;

    int alpha;

    public RockInt() {
        this(0, 0, 0, UNITS_PER_METER);
    }

    public RockInt(float x, float y, float alpha, final float scale) {
        this.scale = scale;
        setX(x);
        setY(y);
        setZ(alpha);
    }

    private RockInt(int x, int y, int alpha, final float scale) {
        this.scale = scale;
        this.x = x;
        this.y = y;
        this.alpha = alpha;
    }

    public Object clone() {
        return new RockInt(x, y, alpha, scale);
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof RockInt))
            return false;
        final RockInt b = (RockInt) obj;
        return x == b.x && y == b.y && alpha == b.alpha;
    }

    public double getX() {
        return x / scale;
    }

    public double getY() {
        return y / scale;
    }

    public double getZ() {
        return alpha / scale;
    }

    public boolean nonzero() {
        return x * x + y * y > 0;
    }

    public void setLocation(double x, double y) {
        setX(x);
        setY(y);
    }

    public void setX(double x) {
        this.x = (int) (x * scale);
    }

    public void setY(double y) {
        this.y = (int) (y * scale);
    }

    public void setZ(double alpha) {
        this.alpha = (int) (alpha * scale);
    }
}