/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser</a>
 * @version $Id$
 */
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Abstract superclass for status implementations. Introduced for structural and
 * grouping reasons and also provides the core functionality. Uses quick
 * {@link java.util.TreeMap}s for the flyweight lookup.
 * 
 * @see java.util.TreeMap
 * @author <a href="mailto:mrohrmoser@gmx-gmbh.de">Marcus Rohrmoser </a>
 * @version $Id: EnumBase.java,v 1.7 2005/02/18 11:21:09 mr Exp $
 */
public abstract class EnumBase extends Number implements Comparable,
        Serializable {

    private static class HashCodeComp implements Comparator {

        public int compare(final Object o1, final Object o2) {
            if (o1 == null && o2 == null)
                return 0;
            if (o1 == null)
                return -1;
            if (o2 == null)
                return 1;
            final int a = o1.hashCode();
            final int b = o2.hashCode();
            if (a < b)
                return -1;
            if (a > b)
                return 1;
            return 0;
        }
    }

    private static final Map types = new TreeMap(new HashCodeComp());

    /**
     * Generic lookup for constant objects.
     * 
     * @param type
     * @param state
     * @return the constant object
     * @throws IllegalArgumentException
     *             if the given state wasn't found.
     */
    public static EnumBase lookup(final Class type, final int state) {
        return lookup(type, new Integer(state));
    }

    /**
     * Generic lookup for constant objects.
     * 
     * @param type
     * @param state
     * @return null ONLY if null was given
     * @throws IllegalArgumentException
     *             if the given state wasn't found.
     */
    public static EnumBase lookup(final Class type, final Integer state) {
        if (state == null)
            return null;
        Map values = (Map) types.get(type);
        if (values == null) {
            try {
                // ensure the class "type" is initialized...
                Class.forName(type.getName());
                values = (Map) types.get(type);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException("Couldn't load class [" + type + "]");
            }
        }
        if (values != null) {
            final EnumBase ret = (EnumBase) values.get(state);
            if (ret != null)
                return ret;
        }
        throw new IllegalArgumentException("Constant not found: [" + state
                + "] for " + type.getName());
    }

    private final Integer state;

    private final String text;

    protected EnumBase(final int state, final String text) {
        this.state = new Integer(state);
        this.text = text;
        // register the value.
        Map values = (Map) types.get(this.getClass());
        if (values == null) {
            synchronized (types) {
                types.put(this.getClass(), values = new TreeMap());
            }
        }
        synchronized (values) {
            values.put(this.state, this);
        }
    }

    public int compareTo(Object o) {
        final EnumBase b = (EnumBase) o;
        return this.state.compareTo(b.state);
    }

    /**
     * @see java.lang.Number#doubleValue()
     */
    public double doubleValue() {
        return intValue();
    }

    public boolean equals(final Object o) {
        if (o == null || !this.getClass().equals(o.getClass()))
            return false;
        return this.state.equals(((EnumBase) o).state);
    }

    /**
     * @see java.lang.Number#floatValue()
     */
    public float floatValue() {
        return intValue();
    }

    private Integer getState() {
        return state;
    }

    /**
     * @return
     */
    public int getValue() {
        return intValue();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return state.hashCode();
    }

    /**
     * @see java.lang.Number#intValue()
     */
    public int intValue() {
        return state.intValue();
    }

    /**
     * @see java.lang.Number#longValue()
     */
    public long longValue() {
        return intValue();
    }

    /**
     * Resolve a read in object (de-serialization).
     * 
     * @return The resolved object read in.
     * 
     * @throws ObjectStreamException
     *             if there is a problem reading the object.
     * @throws RuntimeException
     *             If the read object doesn't exist.
     */
    protected Object readResolve() throws ObjectStreamException {
        return lookup(getClass(), getState());
    }

    public String toString() {
        return this.text;
    }
}