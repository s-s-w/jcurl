/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

import java.io.Serializable;

/**
 * A set of 8 light and 8 dark rocks.
 * 
 * @see jcurl.core.dto.RockFloat
 * @see jcurl.core.dto.RockSetState
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockSet implements Cloneable, Serializable {

    public static final int ROCKS_PER_COLOR = 8;

    public static final int ROCKS_PER_SET = 16;

    public static RockSet allHome() {
        return allHome(null);
    }

    public static RockSet allHome(RockSet ret) {
        ret = ret != null ? ret : new RockSet();
        for (int i = ROCKS_PER_COLOR - 1; i >= 0; i--) {
            Ice.setHome(ret.dark[i], true, i);
            Ice.setHome(ret.light[i], false, i);
        }
        return ret;
    }

    public static RockSet allOut() {
        return allOut(null);
    }

    public static RockSet allOut(RockSet ret) {
        ret = ret != null ? ret : new RockSet();
        for (int i = ROCKS_PER_COLOR - 1; i >= 0; i--) {
            Ice.setOut(ret.dark[i], true, i);
            Ice.setOut(ret.light[i], false, i);
        }
        return ret;
    }

    public static RockSet allZero(RockSet ret) {
        ret = ret != null ? ret : new RockSet();
        for (int i = ROCKS_PER_SET - 1; i >= 0; i--) {
            final Rock ro = ret.getRock(i);
            ro.setLocation(0, 0);
            ro.setZ(0);
        }
        return ret;
    }

    private final RockFloat[] dark = new RockFloat[ROCKS_PER_COLOR];

    private final RockFloat[] light = new RockFloat[ROCKS_PER_COLOR];

    public RockSet() {
        this(true);
    }

    private RockSet(boolean fill) {
        if (fill) {
            for (int i = ROCKS_PER_COLOR - 1; i >= 0; i--) {
                dark[i] = new RockFloat();
                light[i] = new RockFloat();
            }
        }
    }

    public Object clone() {
        final RockSet b = new RockSet(false);
        for (int i = ROCKS_PER_COLOR - 1; i >= 0; i--) {
            b.dark[i] = (RockFloat) (this.dark[i].clone());
            b.light[i] = (RockFloat) (this.light[i].clone());
        }
        return b;
    }

    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof RockSet))
            return false;
        final RockSet b = (RockSet) obj;
        for (int i = ROCKS_PER_COLOR - 1; i >= 0; i--) {
            if (!dark[i].equals(b.dark[i]))
                return false;
            if (!light[i].equals(b.light[i]))
                return false;
        }
        return true;
    }

    public RockFloat getDark(int i) {
        return dark[i];
    }

    public RockFloat getLight(int i) {
        return light[i];
    }

    public Rock getRock(int i) {
        if (i % 2 == 0)
            return dark[i / 2];
        else
            return light[i / 2];
    }
}