/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

import jcurl.core.io.Dim;

/**
 * Rock properties.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockProps {
    public static final RockProps DEFAULT;
    static {
        DEFAULT = new RockProps();
        DEFAULT.mass = 20;
        DEFAULT.radius = Dim.f2m(0.5);
        DEFAULT.inertia = 1.4F;
    }

    public float getInertia() {
        return inertia;
    }

    public float getMass() {
        return mass;
    }

    public float getRadius() {
        return radius;
    }

    private float inertia;

    private float mass;

    private float radius;
}