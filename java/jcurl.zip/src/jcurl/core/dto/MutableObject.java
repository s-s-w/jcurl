/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

import java.beans.PropertyChangeListener;
import java.io.Serializable;

/**
 * Base class for all mutable value Objects. Provides a generic toString and
 * means to notify others upon propery changes. This is necessary for Entity
 * Beans using Transfer Object containers ("dirty" flag).
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id: MutableObject.java,v 1.1 2005/02/02 20:30:31 mr Exp $
 *  
 */
public abstract class MutableObject extends TransferObject implements
        Serializable {
    /** Utility field used by bound properties. */
    protected final transient PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(
            this);

    /**
     * Creates a new instance of MutableObject
     */
    protected MutableObject() {
    }

    /**
     * Adds a PropertyChangeListener to the listener list.
     * 
     * @param listener
     *            The listener to add.
     */
    public void addPropertyChangeListener(final PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Adds a PropertyChangeListener to the listener list for a specific
     * property.
     * 
     * @param property
     *            The property to listen to.
     * @param listener
     *            The listener to add.
     */
    public void addPropertyChangeListener(final String property,
            final PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(property, listener);
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public abstract boolean equals(Object obj);

    /**
     * @see java.lang.Object#hashCode()
     */
    public abstract int hashCode();

    /**
     * Removes a PropertyChangeListener to the listener list.
     * 
     * @param listener
     *            The listener to add.
     */
    public void removePropertyChangeListener(
            final PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    /**
     * Removes a PropertyChangeListener to the listener list for a specific
     * property.
     * 
     * @param property
     *            The property to listen to.
     * @param listener
     *            The listener to add.
     */
    public void removePropertyChangeListener(final String property,
            final PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(property, listener);
    }
}