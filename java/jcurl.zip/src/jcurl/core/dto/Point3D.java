/*
 * Created on 21.02.2005
 *
 */
package jcurl.core.dto;

import java.awt.geom.Point2D;

/**
 * Base class for 3D coordinates.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public abstract class Point3D extends Point2D {

    public abstract double getX();

    public abstract double getY();

    public abstract double getZ();

    /**
     * Sets the location of this Point3D to the specified double coordinates.
     * 
     * @param x,
     *            y, alpha the coordinates of this Point3D
     */
    public void setLocation(double x, double y, double z) {
        this.setX(x);
        this.setY(y);
        this.setZ(z);
    }

    public void setLocation(final Point3D pt) {
        this.setLocation(pt.getX(), pt.getY(), pt.getZ());
    }

    public abstract void setX(double x);

    public abstract void setY(double y);

    public abstract void setZ(double z);
}