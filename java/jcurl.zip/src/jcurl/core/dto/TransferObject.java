/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.dto;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

/**
 * Base class for all value Objects. Provides a generic toString and means to
 * notify others upon propery changes. This is necessary for Entity Beans using
 * Transfer Object containers ("dirty" flag).
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id: TransferObject.java,v 1.4 2005/02/14 15:04:17 mr Exp $
 *  
 */
public abstract class TransferObject implements Serializable {

    //    /**
    //     * @see java.lang.Object#equals(java.lang.Object)
    //     */
    //    public abstract boolean equals(Object obj);
    //
    //    /**
    //     * @see java.lang.Object#hashCode()
    //     */
    //    public abstract int hashCode();

    /**
     * Generic toString method.
     */
    public String toString() { // taken from Hardcore Java (O'reilly, page 228)
        try {
            final BeanInfo info = Introspector.getBeanInfo(this.getClass(),
                    Object.class);
            final PropertyDescriptor[] props = info.getPropertyDescriptors();
            final StringBuffer buf = new StringBuffer(500);
            Object value = null;
            buf.append(getClass().getName());
            buf.append("@"); //$NON-NLS-1$
            buf.append(hashCode());
            buf.append("={"); //$NON-NLS-1$
            for (int idx = 0; idx < props.length; idx++) {
                if (idx != 0) {
                    buf.append(", "); //$NON-NLS-1$
                }
                buf.append(props[idx].getName());
                buf.append("="); //$NON-NLS-1$
                if (props[idx].getReadMethod() != null) {
                    value = props[idx].getReadMethod().invoke(this, null);
                    if (value instanceof TransferObject) {
                        buf.append("@"); //$NON-NLS-1$
                        buf.append(value.hashCode());
                    } else if (value instanceof Collection) {
                        buf.append("{"); //$NON-NLS-1$
                        for (Iterator iter = ((Collection) value).iterator(); iter
                                .hasNext();) {
                            Object element = iter.next();
                            if (element instanceof TransferObject) {
                                buf.append("@"); //$NON-NLS-1$
                                buf.append(element.hashCode());
                            } else {
                                buf.append(element.toString());
                            }
                        }
                        buf.append("}"); //$NON-NLS-1$
                    } else if (value instanceof Map) {
                        buf.append("{"); //$NON-NLS-1$
                        Map map = (Map) value;
                        for (Iterator iter = map.keySet().iterator(); iter
                                .hasNext();) {
                            Object key = iter.next();
                            Object element = map.get(key);
                            buf.append(key.toString() + "=");
                            if (element instanceof TransferObject) {
                                buf.append("@"); //$NON-NLS-1$
                                buf.append(element.hashCode());
                            } else {
                                buf.append(element.toString());
                            }
                        }
                        buf.append("}"); //$NON-NLS-1$
                    } else {
                        buf.append(value);
                    }
                }
            }
            buf.append("}"); //$NON-NLS-1$
            return buf.toString();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}