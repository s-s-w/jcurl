/*
 * Created on 22.02.2005
 *
 */
package jcurl.core.swing;

import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import jcurl.core.dto.Rock;
import jcurl.core.dto.RockProps;
import jcurl.core.dto.RockSet;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockPainter {

    final static Point2D.Float RadiusWC = new Point2D.Float(-2
            * RockProps.DEFAULT.getRadius(), -2 * RockProps.DEFAULT.getRadius());

    private static void paintRock(final Graphics g, final AffineTransform mat,
            final Rock rock, final boolean isDark, final int idx) {
        final Point2D centerwc = rock;
        final Point2D.Float center = new Point2D.Float();
        mat.transform(centerwc, center);
        final Point2D.Float radius = new Point2D.Float();
        mat.deltaTransform(RadiusWC, radius);
        g.drawArc((int) center.x, (int) center.y, (int) radius.x,
                (int) radius.y, 0, 360);
    }

    void paintRocks(final Graphics g, final AffineTransform mat,
            final RockSet rocks) {
        for (int i = RockSet.ROCKS_PER_COLOR - 1; i >= 0; i--) {
            paintRock(g, mat, rocks.getDark(i), true, i);
            paintRock(g, mat, rocks.getLight(i), false, i);
        }
    }

}