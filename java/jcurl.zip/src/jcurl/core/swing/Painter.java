/*
 * Created on 22.02.2005
 *
 */
package jcurl.core.swing;

import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

/**
 * Simple class to paint graphical objects with custom parameter semantics.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class Painter {

    static void rectDC(final Graphics g, final Point2D.Float a,
            final Point2D.Float b) {
        final float x = a.x < b.x ? a.x : b.x;
        final float y = a.y < b.y ? a.y : b.y;
        float width = Math.abs(b.x - a.x);
        float height = Math.abs(b.y - a.y);
        g.drawRect((int) x, (int) y, (int) width, (int) height);
    }

    static void circleDC(final Graphics g, final Point2D.Float a,
            final Point2D.Float b) {
        float width = 2 * Math.abs(b.x - a.x);
        float height = 2 * Math.abs(b.y - a.y);
        float tlx = a.x - width / 2;
        float tly = a.y - height / 2;
        g.drawArc((int) (tlx), (int) (tly), (int) (width), (int) (height), 0,
                360);
    }

    static void lineDC(final Graphics g, final Point2D.Float a,
            final Point2D.Float b) {
        g.drawLine((int) a.x, (int) a.y, (int) b.x, (int) b.y);
    }

    static void wc2dc(final AffineTransform mat, final Point2D[] wc,
            final Point2D[] dc) {
        for (int i = wc.length - 1; i >= 0; i--) {
            final Point2D pwc = wc[i];
            if (pwc == null)
                continue;
            dc[i] = mat.transform(pwc, dc[i]);
        }
    }
}