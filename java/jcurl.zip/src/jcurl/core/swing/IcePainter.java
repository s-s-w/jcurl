/*
 * Created on 22.02.2005
 *
 */
package jcurl.core.swing;

import java.awt.Graphics;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class IcePainter {

    /**
     * Doesn't need a matrix as it only uses (yet transformed) {@link Pt}
     * objects.
     * 
     * @param g
     */
    public void paintIce(final Graphics g) {
        // hog to hog
        Painter.rectDC(g, Pt.fhl.dc, Pt.nhr.dc);
        // hog to tee
        Painter.rectDC(g, Pt.nhl.dc, Pt.tr.dc);
        // tee to back
        Painter.rectDC(g, Pt.tl.dc, Pt.br.dc);
        // button
        Painter.circleDC(g, Pt.zero.dc, Pt.tr1.dc);
        // 4-foot circle
        Painter.circleDC(g, Pt.zero.dc, Pt.tr4.dc);
        // 8-foot circle
        Painter.circleDC(g, Pt.zero.dc, Pt.tr8.dc);
        // 12-foot circle
        Painter.circleDC(g, Pt.zero.dc, Pt.tr12.dc);
        // Tee line
        Painter.lineDC(g, Pt.tl.dc, Pt.tr.dc);
        // Near Hog line
        Painter.lineDC(g, Pt.nhl.dc, Pt.nhr.dc);
        // Far Hog line
        Painter.lineDC(g, Pt.fhl.dc, Pt.fhr.dc);
        // Center
        Painter.lineDC(g, Pt.fHackC.dc, Pt.nHackC.dc);
    }
}