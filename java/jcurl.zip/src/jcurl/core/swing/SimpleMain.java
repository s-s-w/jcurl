/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.swing;

import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import jcurl.core.CollissionSimple;
import jcurl.core.RealTimePlayer;
import jcurl.core.RockSetInterpolator;
import jcurl.core.RunComputer;
import jcurl.core.SlideSimple;
import jcurl.core.Source;
import jcurl.core.Target;
import jcurl.core.dto.RockSet;
import jcurl.core.dto.RockSetProps;

import org.apache.log4j.Logger;

/**
 * @see jcurl.core.SlideSimple
 * @see jcurl.core.CollissionSimple
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class SimpleMain extends JFrame {

    private static final Logger log = Logger.getLogger(SimpleMain.class);

    private final Target dst;

    public SimpleMain() {
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        setTitle("CurlDemo");
        setSize(600, 400);
        Container contentPane = getContentPane();
        // add a keyboard handler!

        final JCurlPanel mp = new JCurlPanel(null, null);
        contentPane.add(mp);
        dst = mp;
    }

    public static void main(String[] args) {
        // initial state
        final RockSet pos = RockSet.allOut();
        pos.getDark(0).setLocation(0, 5, 0);
        pos.getLight(0).setLocation(0.2, 2.5);
        pos.getLight(1).setLocation(1.0, 1.5);
        final RockSet speed = new RockSet();
        speed.getDark(0).setLocation(0, -1.0);

        // dynamics engines
        final Source src = new RunComputer(new SlideSimple(),
                new CollissionSimple(), new RockSetInterpolator(),
                RockSetProps.DEFAULT, 0, pos, speed);
        // set up the keyboard handler

        // display
        final SimpleMain frame = new SimpleMain();
        frame.show();

        // trigger start!
        final RealTimePlayer r = new RealTimePlayer(src.getMinT(), 1.0, src,
                frame.dst);
        //r.run();
        new Thread(r).start();
    }
}