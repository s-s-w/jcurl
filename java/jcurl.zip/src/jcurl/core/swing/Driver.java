/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.swing;

import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import jcurl.core.dto.RockSet;

import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class Driver extends JFrame {

    private static final Logger log = Logger.getLogger(Driver.class);

    public Driver() {
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        setTitle("CurlDemo");
        setSize(600, 400);
        Container contentPane = getContentPane();
        final RockSet rs = RockSet.allOut();
        final JCurlPanel mp = new JCurlPanel(rs, ZoomArea.HOUSE);
        contentPane.add(mp);
    }

    public static void main(String[] args) {
        JFrame frame = new Driver();
        frame.show();
    }
}