/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;
import jcurl.core.dto.RockSetProps;
import junit.framework.TestCase;

/**
 * @see jcurl.core.RockSetInterpolator
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RockSetInterpolatorTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(RockSetInterpolatorTest.class);
    }

    public void test010_feed() {
        final long t0 = 0;
        RockSet rPos = RockSet.allHome();
        rPos.getLight(0).setLocation(0, 0);
        RockSet rSpeed = new RockSet();
        rSpeed.getLight(0).setX(0);
        rSpeed.getLight(0).setY(1);
        SlideSimple slid = new SlideSimple();
        assertTrue(slid.isDiscrete());

        slid.reset(t0, rPos, rSpeed, RockSetProps.DEFAULT);
        assertEquals(t0, slid.getMinT());

        final RockSetInterpolator ip = new RockSetInterpolator();

        final int loop = 5000;
        for (int i = 0; i < loop; i++) {
            long t1 = t0 + i * 2;
            RockSet p1 = slid.getPos(t1, null);
            ip.setPos(t1, p1);
        }
        for (int i = loop - 2; i >= 0; i--) {
            long t1 = t0 + i * 2 + 1;
            ip.getPos(t1, null);
        }
    }
}