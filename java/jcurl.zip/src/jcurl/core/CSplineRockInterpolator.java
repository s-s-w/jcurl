/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.Rock;
import jcurl.core.dto.RockFloat;
import jcurl.core.math.CSplineInterpolator;

/**
 * Use cubic splines {@link jcurl.core.math.CSplineInterpolator}to interpolate
 * the rock's trajectory.
 * 
 * @see jcurl.core.math.CSplineInterpolator
 * @see jcurl.core.RockSetInterpolator
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class CSplineRockInterpolator implements IRockInterpolator {

    private final CSplineInterpolator alpha;

    private final CSplineInterpolator x;

    private final CSplineInterpolator y;

    /**
     *  
     */
    public CSplineRockInterpolator() {
        x = new CSplineInterpolator();
        y = new CSplineInterpolator();
        alpha = new CSplineInterpolator();
    }

    public void add(final long t, final Rock rock) {
        add(t, rock, false);
    }
    public void add(final long t, final Rock rock,
            final boolean discontinuous) {
        x.add(t, rock.getX());
        y.add(t, rock.getY());
        alpha.add(t, rock.getZ());
    }

    public long getMaxT() {
        return (long) x.getMaxX();
    }

    public long getMinT() {
        return (long) x.getMinX();
    }

    public Rock getPos(final long t, final Rock rock) {
        final Rock ret = rock == null ? new RockFloat() : rock;
        ret.setX(x.getC0(t));
        ret.setY(y.getC0(t));
        ret.setZ(alpha.getC0(t));
        return ret;
    }

    public Rock getSpeed(final long t, final Rock rock) {
        final Rock ret = rock == null ? new RockFloat() : rock;
        ret.setX(x.getC1(t));
        ret.setY(y.getC1(t));
        ret.setZ(alpha.getC1(t));
        return ret;
    }

    public void reset() {
        x.reset();
        y.reset();
        alpha.reset();
    }
}