/*
 * Created on 20.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;

/**
 * Abstract base class for collission models.
 * 
 * @see jcurl.core.RunComputer
 * @see jcurl.core.SlideStrategy
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public abstract class CollissionStrategy {

    protected static final double sqr(final double a) {
        return a * a;
    }

    public abstract int computeHit(RockSet pos, RockSet speed);
}