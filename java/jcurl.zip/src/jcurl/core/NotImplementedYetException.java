/*
 * Created on 20.02.2005
 *
 */
package jcurl.core;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class NotImplementedYetException extends UnsupportedOperationException {

    /**
     *  
     */
    public NotImplementedYetException() {
        super("Not implemented yet.");
    }

}