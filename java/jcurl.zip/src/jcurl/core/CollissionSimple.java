/*
 * Created on 20.02.2005
 *
 */
package jcurl.core;

import java.awt.geom.Point2D;

import jcurl.core.dto.Rock;
import jcurl.core.dto.RockProps;
import jcurl.core.dto.RockSet;
import jcurl.core.math.MathVec;

/**
 * Compute collissions without bothering about inertia. A very simple hit-model
 * only exchanging the speed-components along the hit-direction of the first two
 * involved rocks. Only conservation of momentum is obeyed, e.g. spin is
 * neglected.
 * 
 * @see jcurl.core.SlideSimple
 * @see jcurl.core.CollissionSimpleTest
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class CollissionSimple extends CollissionStrategy {

    public int computeHit(RockSet pos, RockSet speed) {
        final float Rad = RockProps.DEFAULT.getRadius();
        final float HIT_MAX_DIST = 1e-3F;
        final double RR = sqr(Rad + Rad + HIT_MAX_DIST);
        int hits = 0;
        for (int B = 0; B < RockSet.ROCKS_PER_SET; B++) {
            for (int A = 0; A < B; A++) {
                final Rock xa = pos.getRock(A);
                final Rock xb = pos.getRock(B);
                final Rock va = speed.getRock(A);
                final Rock vb = speed.getRock(B);
                // vector from A's center to B's:
                final Point2D xr = MathVec.sub(xb, xa, new Point2D.Double());
                final double xrxr = MathVec.scal(xr, xr);
                if (xrxr > RR || !(va.nonzero() || vb.nonzero()))
                    continue;

                // get the speed of approach (A -> B):
                final Point2D vr = MathVec.sub(vb, va, new Point2D.Double());
                // get the (speed) component along xr
                double scal = MathVec.scal(xr, vr);
                double vrabs = MathVec.abs(vr);
                MathVec.mult(scal / xrxr, xr); //r *= r * dv;

                // exchange speed
                MathVec.add(va, xr, va);
                MathVec.sub(vb, xr, vb);

                // mark the rocks' bits hit
                hits |= (1 << A);
                hits |= (1 << B);
            }
        }
        return hits;
    }
}