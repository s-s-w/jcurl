/*
 * Created on 20.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;
import jcurl.core.dto.RockSetProps;

/**
 * Interface for classes providing rock location and speed data.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public interface Source {

    /**
     * 
     * @return the max yet known time.
     */
    public abstract long getMaxT();

    /**
     * 
     * @return the start time
     */
    public abstract long getMinT();

    public abstract RockSet getPos(final long time, RockSet rocks);

    /**
     * Optional
     * 
     * @param time
     * @param rocks
     * @return
     */
    public abstract RockSet getSpeed(final long time, RockSet rocks);

    public abstract boolean isDiscrete();

    public abstract boolean isForwardOnly();

    public abstract boolean isWithSpeed();

    public abstract void reset(long startTime, RockSet startPos,
            RockSet startSpeed, RockSetProps props);
}