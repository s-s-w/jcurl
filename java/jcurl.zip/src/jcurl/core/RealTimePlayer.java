/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;

/**
 * Extract locations from a (non-discrete) {@link jcurl.core.Source}and push
 * them into a {@link Target}.
 * 
 * @see jcurl.core.Source
 * @see jcurl.core.Target
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class RealTimePlayer implements Runnable {

    private final Target dst;

    private final Source src;

    private final long t0;

    private final double timeScale;

    private final long timeSleep = 10;

    public RealTimePlayer(final long t0, final double scale, final Source src,
            final Target dst) {
        this.t0 = t0;
        this.timeScale = scale;
        this.src = src;
        this.dst = dst;
    }

    /**
     * 
     * @see java.lang.Runnable#run()
     */
    public void run() {
        final RockSet rs = RockSet.allHome();
        final long start = System.currentTimeMillis();
        // push them to the target
        for (;;) {
            final long dt = System.currentTimeMillis() - start;
            if (dt > 10000)
                break;
            final long t = t0 + (long) (dt * timeScale);
            src.getPos(t, rs);
            if (dst != null)
                dst.setPos(t, rs);
            try {
                Thread.sleep(timeSleep);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}