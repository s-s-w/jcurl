/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import jcurl.core.CollissionStrategy;
import jcurl.core.SlideStrategy;
import jcurl.core.dto.Ice;
import jcurl.core.dto.RockSet;
import jcurl.core.dto.RockSetProps;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class Config {

    static DimVal getDim(String token) {
        if ("HACK".equals(token))
            return new DimVal(Ice.FAR_HACK_2_TEE, Dim.METER);
        if ("FHOG".equals(token))
            return new DimVal(Ice.HOG_2_HOG + Ice.HOG_2_TEE, Dim.METER);
        if ("NHOG".equals(token))
            return new DimVal(Ice.HOG_2_TEE, Dim.METER);
        return DimVal.parse(token);
    }

    public static Config load(final File in) throws FileNotFoundException {
        return load(new FileReader(in));
    }

    public static Config load(final InputStream in, final String encoding)
            throws UnsupportedEncodingException {
        return load(new InputStreamReader(in, encoding));
    }

    public static Config load(final Reader in) {
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    private Config() {

    }

    public CollissionStrategy getHitter() {
        return null;
    }

    public RockSet getPosition() {
        return null;
    }

    public RockSetProps getProps() {
        return null;
    }

    public SlideStrategy getSlider() {
        return null;
    }

    public long getTime() {
        return -1;
    }

    public RockSet getSpeed() {
        return null;
    }
}