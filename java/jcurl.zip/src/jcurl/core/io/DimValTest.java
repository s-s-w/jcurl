/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.io;

import junit.framework.TestCase;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class DimValTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(DimValTest.class);
    }

    public void test010_Convert() {
        DimVal in = new DimVal(12, Dim.INCH);
        DimVal ft = new DimVal(1, Dim.FOOT);
        DimVal m = new DimVal(0.3048, Dim.METER);

        assertEquals(m, m.to(Dim.METER));
        assertEquals(m, in.to(Dim.METER));
        assertEquals(m, ft.to(Dim.METER));
    }
}