/*
 * Created on 20.02.2005
 *  
 */
package jcurl.core.io;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A value with attached unit of measurement {@link Dim}.
 * 
 * @see jcurl.core.io.Dim
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
class DimVal {
    private static final Pattern pat = Pattern
            .compile("^(-?[0-9]+([.][0-9]+)?(e-?[0-9]))(.*)$");

    public static DimVal parse(final String txt) {
        // split the string
        final Matcher mat = pat.matcher(txt);
        if (mat.matches()) {
            for (int i = 0; i < mat.groupCount(); i++)
                System.out.println(i + "=" + mat.group(i));
            final String val = mat.group(1);
            final String dim = mat.group(4);
            try {
                return new DimVal(Double.parseDouble(val), Dim.find(dim));
            } catch (RuntimeException e) {
                final IllegalArgumentException a = new IllegalArgumentException(
                        "Not a dimension: [" + txt + "]");
                a.initCause(e);
                throw a;
            }
        }
        throw new IllegalArgumentException("Not a dimension: [" + txt + "]");
    }

    public final Dim dim;

    public final double val;

    public DimVal(double value, final Dim dim) {
        this.val = value;
        this.dim = dim;
    }

    public boolean equals(final Object o) {
        if (o == null || !(o instanceof DimVal))
            return false;
        final DimVal b = (DimVal) o;
        if (!this.dim.equals(b.dim))
            return false;
        if (this.val == b.val)
            return true;
        return false;
    }

    public DimVal to(final Dim dst) {
        if (this.dim.BaseDim.getValue() != dst.BaseDim.getValue())
            throw new IllegalArgumentException("Units are not convertible ("
                    + this.dim.toString() + "->" + dst.toString() + ")");
        // this -> si -> dst
        return new DimVal(this.val * (this.dim.Factor / dst.Factor), dst);
    }

    public String toString() {
        return Double.toString(val) + dim.toString();
    }
}