/*
 * Created on 20.02.2005
 *
 */
package jcurl.core.io;

import junit.framework.TestCase;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class ConfigTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(ConfigTest.class);
    }

    public void test010_ToDim() {
        Dim di = Dim.INCH;
        DimVal dim = Config.getDim("-1.4e-3m/s");
        assertEquals(Dim.METER_PER_SEC, dim.dim);
        //assertEquals(-1.4e-3, dim.value);
    }
}