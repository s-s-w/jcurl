/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.RockSet;

/**
 * Interface for classes requiring rock location data.
 * 
 * @see jcurl.core.RockSetInterpolator
 * @see jcurl.core.swing.JCurlPanel
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public interface Target {

    public void setPos(final long t, final RockSet rocks);

    /**
     * 
     * @param t
     * @param rocks
     * @param discontinuous
     *            bitmask of discontinuous rocks as returned by
     *            {@link CollissionStrategy#computeHit(RockSet, RockSet)}.
     */
    public void setPos(final long t, final RockSet rocks,
            final int discontinuous);
}