/*
 * Created on 27.02.2005
 *
 */
package jcurl.core;

import jcurl.core.dto.Rock;

/**
 * Interface for interpolators of single rocks.
 * 
 * @see jcurl.core.RockSetInterpolator
 * @see jcurl.core.CSplineRockInterpolator
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public interface IRockInterpolator {
    public abstract void add(final long t, final Rock rock);

    public abstract void add(final long t, final Rock rock,
            final boolean discontinuous);

    public abstract long getMaxT();

    public abstract long getMinT();

    public abstract Rock getPos(final long t, final Rock rock);

    public abstract Rock getSpeed(final long t, final Rock rock);

    public abstract void reset();
}