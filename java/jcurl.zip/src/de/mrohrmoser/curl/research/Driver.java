/*
 * Created on 19.02.2005
 *
 */
package de.mrohrmoser.curl.research;

import javax.swing.JFrame;

import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class Driver {
    private static final Logger log = Logger.getLogger(Driver.class);

    public static void main(String[] args) {
        JFrame frame = new MainFrame();
        frame.show();
    }
}