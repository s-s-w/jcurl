/*
 * Created on 19.02.2005
 *
 */
package de.mrohrmoser.curl.research;

import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import org.apache.log4j.Logger;

import de.mrohrmoser.curl.math.PointList;

/**
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class MainFrame extends JFrame {

    private static final Logger log = Logger.getLogger(MainFrame.class);

    private final PointList curve;

    public MainFrame() {
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                log.info("Points collected: " + curve.size());
                System.exit(0);
            }
        });
        setTitle("FirstFrame");
        setSize(600, 600);
        Container contentPane = getContentPane();
        //contentPane.add(new KeySketchPanel());
        //contentPane.add(new MouseRectPanel());
        final MouseSketchPanel mp = new MouseSketchPanel(' ');
        this.curve = mp.getCurve();
        contentPane.add(mp);
    }
}