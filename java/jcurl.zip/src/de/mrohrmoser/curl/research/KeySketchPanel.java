/*
 * Created on 19.02.2005
 *
 */
package de.mrohrmoser.curl.research;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

/**
 * Draw lines using the keyboard.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class KeySketchPanel extends JPanel implements KeyListener {

    private Point end = new Point(0, 0);

    private Point start = new Point(0, 0);

    public KeySketchPanel() {
        addKeyListener(this);
    }

    public void add(int dx, int dy) {
        end.x += dx;
        end.y += dy;
        Graphics g = getGraphics();
        g.drawLine(start.x, start.y, end.x, end.y);
        g.dispose();
        start.x = end.x;
        start.y = end.y;
    }

    public boolean isFocusTraversable() {
        return true;
    }

    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        int d;
        if (e.isShiftDown())
            d = 5;
        else
            d = 1;
        if (keyCode == KeyEvent.VK_LEFT)
            add(-d, 0);
        else if (keyCode == KeyEvent.VK_RIGHT)
            add(d, 0);
        else if (keyCode == KeyEvent.VK_UP)
            add(0, -d);
        else if (keyCode == KeyEvent.VK_DOWN)
            add(0, d);

    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
        char keyChar = e.getKeyChar();
        int d;
        if (Character.isUpperCase(keyChar)) {
            d = 5;
            keyChar = Character.toLowerCase(keyChar);
        } else
            d = 1;
        if (keyChar == 'h')
            add(-d, 0);
        else if (keyChar == 'l')
            add(d, 0);
        else if (keyChar == 'k')
            add(0, -d);
        else if (keyChar == 'j')
            add(0, d);
    }
}