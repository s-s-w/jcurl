/*
 * Created on 19.02.2005
 *
 */
package de.mrohrmoser.curl.research;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Iterator;

import javax.swing.JPanel;

import org.apache.log4j.Logger;

import de.mrohrmoser.curl.math.PointList;

/**
 * Draw lines if the "hot" key is pressed.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class MouseSketchPanel extends JPanel implements KeyListener {

    private static final Logger log = Logger.getLogger(MouseSketchPanel.class);

    /**
     * Paint the given curve.
     * 
     * @param g
     * @param c
     */
    private static void paint(final Graphics g, final PointList c) {
        final Iterator it = c.points();
        if (!it.hasNext())
            return;
        Point p = (Point) it.next();
        while (it.hasNext()) {
            final Point p2 = (Point) it.next();
            g.drawLine(p.x, p.y, p2.x, p2.y);
            p = p2;
        }
    }

    private Point current = null;

    private final PointList curve = new PointList();

    private final char hotKey;

    private boolean isHot = false;

    public MouseSketchPanel(final char hotKey) {
        this.hotKey = hotKey;
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                if (isHot)
                    lineTo(e.getPoint());
            }
        });
        addKeyListener(this);
    }

    public PointList getCurve() {
        return curve;
    }

    public boolean isFocusTraversable() {
        return true;
    }

    public void keyPressed(KeyEvent e) {
        if (e.getKeyChar() == hotKey) {
            log.debug("HotKey pressed");
            isHot = true;
        }
        switch (e.getKeyCode()) {
        case KeyEvent.VK_ESCAPE:
            this.current = null;
            this.curve.clear();
            this.repaint();
            break;
        case KeyEvent.VK_F1:
            final Graphics g = getGraphics();
            paint(g, PointList.getLine(curve));
            g.dispose();
            break;
        }
    }

    public void keyReleased(KeyEvent e) {
        if (e.getKeyChar() == hotKey) {
            log.debug("HotKey released");
            isHot = false;
        }
    }

    public void keyTyped(KeyEvent e) {
    }

    private void lineTo(final Point p) {
        if (current != null) {
            log.debug("draw line");
            final Graphics g = getGraphics();
            g.drawLine(current.x, current.y, p.x, p.y);
            g.dispose();
        }
        curve.add(current = p);
    }
}