/*
 * Created on 01.03.2005
 *
 */
package de.mrohrmoser.curl.math;

import java.io.IOException;
import java.text.ParseException;
import java.util.Map;
import java.util.TreeMap;

import junit.framework.TestCase;

/**
 * JUnit Test.
 * 
 * @see de.mrohrmoser.curl.math.Calc0
 * @see de.mrohrmoser.curl.math.Calc1
 * @see de.mrohrmoser.curl.math.MathDom
 * @see de.mrohrmoser.curl.math.ParserInfix
 * @see de.mrohrmoser.curl.math.DomWalkerInfix
 * @see de.mrohrmoser.curl.math.DomWalkerPostfix
 * @see de.mrohrmoser.curl.math.DomWalkerEval
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class CalcTest extends TestCase {

    public static void main(String[] args) {
        junit.textui.TestRunner.run(CalcTest.class);
    }

    public void test010_0() throws IOException {
        Calc0 c = new Calc0(" 2 * 4 +3 ");
        assertEquals("", 11, c.compute(), 1e-9);

        c = new Calc0(" 2 * (4 +3) ");
        assertEquals("", 14, c.compute(), 1e-9);

        c = new Calc0(" 2 / 4 +3 ");
        assertEquals("", 3.5, c.compute(), 1e-9);
    }

    public void test020_1() throws IOException {
        Calc1 c = new Calc1(" 2 * 4 +3 ");
        assertEquals("", 11, c.compute(), 1e-9);

        c = new Calc1(" 2 * (3-4) ");
        assertEquals("", -2, c.compute(), 1e-9);

        c = new Calc1(" 2 * abs(3-4) ");
        assertEquals("", 2, c.compute(), 1e-9);

        c = new Calc1(" 2 / 4 +3 ");
        assertEquals("", 3.5, c.compute(), 1e-9);
    }

    public void test030_Dom() throws ParseException {
        MathDom.Node n = ParserInfix.parse(" 2 * 4 +3 ");
        assertEquals("2.0 * 4.0 + 3.0", DomWalkerInfix.toString(n));
        assertEquals(" +  * 2.0 4.0 3.0", DomWalkerPostfix.toString(n));
        assertEquals("", 11, DomWalkerEval.eval(n), 1e-9);

        n = ParserInfix.parse(" 2 * (3-4) ");
        assertEquals("2.0 * (3.0 - 4.0)", DomWalkerInfix.toString(n));
        assertEquals(" * 2.0  - 3.0 4.0", DomWalkerPostfix.toString(n));
        assertEquals("", -2, DomWalkerEval.eval(n), 1e-9);

        n = ParserInfix.parse(" 2 * abs(3-4) ");
        assertEquals("2.0 * abs(3.0 - 4.0)", DomWalkerInfix.toString(n));
        assertEquals(" * 2.0 abs  - 3.0 4.0", DomWalkerPostfix.toString(n));
        assertEquals("", 2, DomWalkerEval.eval(n), 1e-9);

        n = ParserInfix.parse(" 2 / 4 +3 ");
        assertEquals("2.0 / 4.0 + 3.0", DomWalkerInfix.toString(n));
        assertEquals(" +  / 2.0 4.0 3.0", DomWalkerPostfix.toString(n));
        assertEquals("", 3.5, DomWalkerEval.eval(n), 1e-9);
    }

    public void test040_Param() throws ParseException {
        Map p = new TreeMap();
        MathDom.Node n = ParserInfix.parse("sqrt2=sqrt(2)");
        assertEquals("sqrt2 = sqrt(2.0)", DomWalkerInfix.toString(n));
        assertEquals(" = sqrt2 sqrt 2.0", DomWalkerPostfix.toString(n));
        assertEquals("", Math.sqrt(2), DomWalkerEval.eval(n, p), 1e-9);
        assertEquals("", Math.sqrt(2), ((Number) p.get("sqrt2")).doubleValue(),
                1e-9);

        n = ParserInfix.parse("sqrt2 * sqrt2");
        assertEquals("", 2, DomWalkerEval.eval(n, p), 1e-9);
    }

    public void test050_Loop() throws ParseException {
        // parsing
        int loop = 100000;
        long start = System.currentTimeMillis();
        for (int i = loop - 1; i >= 0; i--) {
            MathDom.Node n = ParserInfix.parse(" 2 * 4 +3 ");
        }
        long dt = System.currentTimeMillis() - start;
        long cps = loop * 1000 / dt;
        assertTrue(cps > 50000);

        // evaluation
        final MathDom.Node n = ParserInfix.parse(" 2 * 4 +3 ");
        final DomWalkerEval de = new DomWalkerEval();
        start = System.currentTimeMillis();
        for (int i = loop - 1; i >= 0; i--) {
            de.walk(n);
        }
        dt = System.currentTimeMillis() - start;
        cps = loop * 1000 / dt;
        assertTrue(cps > 2000000);

        // hard coded arithmetics
        loop *= 100;
        start = System.currentTimeMillis();
        double d;
        for (int i = loop - 1; i >= 0; i--) {
            d = 2.0 * 4.0 + 3.0;
        }
        dt = System.currentTimeMillis() - start;
        cps = loop * 1000 / dt;
        assertTrue(cps > 18000000);
    }
}