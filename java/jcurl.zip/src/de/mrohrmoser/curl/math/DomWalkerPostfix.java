/*
 * Created on 01.03.2005
 *
 */
package de.mrohrmoser.curl.math;

/**
 * Convert the expression to postfix (reverse polish) notation.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class DomWalkerPostfix extends DomWalker {

    public static String toString(final MathDom.Node n) {
        return toString(n, new StringBuffer()).toString();
    }

    public static StringBuffer toString(final MathDom.Node n,
            final StringBuffer buf) {
        final DomWalkerPostfix w = new DomWalkerPostfix(buf);
        w.walk(n);
        return w.buf;
    }

    public final StringBuffer buf;

    public DomWalkerPostfix() {
        this(new StringBuffer());
    }

    public DomWalkerPostfix(StringBuffer b) {
        this.buf = b;
    }

    public void reset() {
        buf.setLength(0);
    }

    public void walk(MathDom.BinaryOp n) {
        buf.append(' ');
        buf.append(n.op).append(' ');
        walk(n.left);
        buf.append(' ');
        walk(n.right);
    }

    public void walk(MathDom.Block n) {
        walk(n.arg);
    }

    public void walk(MathDom.Function n) {
        buf.append(n.name).append(' ');
        walk(n.arg);
    }

    public void walk(MathDom.Literal n) {
        buf.append(n.val);
    }

    public void walk(MathDom.Parameter n) {
        buf.append(n.name);
    }

    public void walk(MathDom.UnaryOp n) {
        buf.append(n.op);
        walk(n.arg);
    }
}