/*
 * Created on 01.03.2005
 *
 */
package de.mrohrmoser.curl.math;

/**
 * Convert the expression to infix notation.
 * 
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public class DomWalkerInfix extends DomWalker {

    public static String toString(final MathDom.Node n) {
        return toString(n, new StringBuffer()).toString();
    }

    public static StringBuffer toString(final MathDom.Node n,
            final StringBuffer buf) {
        final DomWalkerInfix w = new DomWalkerInfix(buf);
        w.walk(n);
        return w.b;
    }

    public final StringBuffer b;

    public DomWalkerInfix() {
        this(new StringBuffer());
    }

    public DomWalkerInfix(StringBuffer b) {
        this.b = b;
    }

    public void reset() {
        b.setLength(0);
    }

    public void walk(MathDom.BinaryOp n) {
        walk(n.left);
        b.append(' ').append(n.op).append(' ');
        walk(n.right);
    }

    public void walk(MathDom.Block n) {
        b.append('(');
        walk(n.arg);
        b.append(')');
    }

    public void walk(MathDom.Function n) {
        b.append(n.name).append('(');
        walk(n.arg);
        b.append(')');
    }

    public void walk(MathDom.Literal n) {
        b.append(n.val);
    }

    public void walk(MathDom.Parameter n) {
        b.append(n.name);
    }

    public void walk(MathDom.UnaryOp n) {
        b.append(n.op);
        walk(n.arg);
    }
}