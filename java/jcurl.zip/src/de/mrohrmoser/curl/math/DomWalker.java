/*
 * Created on 01.03.2005
 *
 */
package de.mrohrmoser.curl.math;

/**
 * Base class for dom tree walkers.
 * 
 * @see de.mrohrmoser.curl.math.MathDom
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public abstract class DomWalker {

    public abstract void reset();

    public abstract void walk(MathDom.BinaryOp n);

    public abstract void walk(MathDom.Block n);

    public abstract void walk(MathDom.Function n);

    public abstract void walk(MathDom.Literal n);

    public void walk(MathDom.Node n) {
        if (n instanceof MathDom.BinaryOp)
            walk((MathDom.BinaryOp) n);
        else if (n instanceof MathDom.Block)
            walk((MathDom.Block) n);
        else if (n instanceof MathDom.Function)
            walk((MathDom.Function) n);
        else if (n instanceof MathDom.Literal)
            walk((MathDom.Literal) n);
        else if (n instanceof MathDom.Parameter)
            walk((MathDom.Parameter) n);
        else if (n instanceof MathDom.UnaryOp)
            walk((MathDom.UnaryOp) n);
        else
            throw new IllegalStateException("Unknown node type ["
                    + n.getClass().getName() + "]");
    }

    public abstract void walk(MathDom.Parameter n);

    public abstract void walk(MathDom.UnaryOp n);
}