/*
 * Created on 01.03.2005
 *
 */
package de.mrohrmoser.curl.math;

/**
 * Simple DOM for arithmetic expressions. Capable of literals, parameters (R1),
 * functions, parenthesises, unary and binary operators.
 * 
 * @see de.mrohrmoser.curl.math.ParserInfix
 * @see de.mrohrmoser.curl.math.DomWalker
 * @author <a href="mailto:m@mrohrmoser.de">Marcus Rohrmoser </a>
 * @version $Id$
 */
public abstract class MathDom {

    public static class BinaryOp extends Operator {

        public final Node left;

        public final Node right;

        public BinaryOp(final char op, final Node left, final Node right) {
            super(op);
            this.left = left;
            this.right = right;
        }
    }

    public static class Block extends Node {

        public final Node arg;

        public Block(final Node arg) {
            this.arg = arg;
        }
    }

    public static class Function extends Node {

        public final Node arg;

        public final String name;

        public Function(final String name, final Node arg) {
            this.name = name;
            this.arg = arg;
        }
    }

    public static class Integer extends Literal {
        public final int ival;

        public Integer(final int val) {
            super(val);
            this.ival = val;
        }
    }

    public static class Literal extends Value {
        public final double val;

        public Literal(final double val) {
            this.val = val;
        }
    }

    public static abstract class Node {
    }

    public abstract static class Operator extends Node {
        public final char op;

        public Operator(final char op) {
            this.op = op;
        }
    }

    public static class Parameter extends Value {
        public final String name;

        public Parameter(final String name) {
            this.name = name;
        }
    }

    public static class UnaryOp extends Operator {

        public final Node arg;

        public UnaryOp(final char op, final Node arg) {
            super(op);
            this.arg = arg;
        }
    }

    public static abstract class Value extends Node {
    }
}